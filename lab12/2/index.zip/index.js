const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

let flashMessage = '';

app.get('/', (req, res) => {
    if (req.cookies.employee) {
        res.render('employee', { 
            employee: null,
            message: flashMessage
        });
        flashMessage = '';
    } else {
    db.get('SELECT * FROM employees LIMIT 1', (err, employee) => {
        if (err) {
        console.error(err.message);
        return res.status(500).send('Database error');
        }
        
        res.render('employee', { 
        employee: employee, 
        message: flashMessage
        });
        flashMessage = '';
    });
    }
});

app.post('/employee/save', (req, res) => {
  const { id, firstname, lastname, address, email, phone } = req.body;

  if (!firstname || !lastname || !email || !phone) {
    req.session.message = 'All fields are required';
    return res.redirect('/');
  }
  
  const employeeData = JSON.stringify({
    id,
    firstname,
    lastname,
    address,
    email: email.trim(),
    phone: phone.trim()
  });
  
  res.cookie('employee', employeeData, { 
    maxAge: 3600000,
    httpOnly: true
  });
  
  flashMessage = 'Employee data saved to cookie!';
  
  res.redirect('/');
});

app.get('/employee/show', (req, res) => {
  if (req.cookies.employee) {
    try {
      const employee = JSON.parse(req.cookies.employee);
      
      res.render('employee', { 
        employee: employee,
        message: 'Data retrieved from cookie'
      });
    } catch (error) {
      console.error('Error parsing cookie:', error);
      flashMessage = 'Error retrieving data from cookie';
      res.redirect('/');
    }
  } else {
    res.render('employee', { 
      employee: null,
      message: 'No data found in cookie'
    });
  }
});


app.get('/employee/clear', (req, res) => {
  res.clearCookie('employee');

  flashMessage = 'Employee data cleared from cookie!';

  res.redirect('/');
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});