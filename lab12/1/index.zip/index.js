const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'lab12-session-secret',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 3600000 }
}));


app.get('/', (req, res) => {

    if (req.session.employee) {
        res.render('employee', { 
            employee: null,
            message: req.session.message
        });
      } else {
        db.get('SELECT * FROM employees LIMIT 1', (err, employee) => {
            if (err) {
                console.error(err.message);
                return res.status(500).send('Database error');
            }
            res.render('employee', { 
                employee: employee, 
                message: req.session.message || ''
            });
            req.session.message = '';
            });
      }
});
  
app.post('/employee/save', (req, res) => {
    const { id, firstname, lastname, address, email, phone } = req.body;
    
    if (!firstname || !lastname || !email || !phone) {
      req.session.message = 'All fields are required';
      return res.redirect('/');
    }

    req.session.employee = {
      id,
      firstname,
      lastname,
      address,
      email: email.trim(),
      phone: phone.trim()
    };
    
    req.session.message = 'Employee data saved to session!';
    res.redirect('/');
  });

app.get('/employee/show', (req, res) => {
  if (req.session.employee) {
    res.render('employee', { 
      employee: req.session.employee,
      message: 'Data retrieved from session'
    });
  } else {
    res.render('employee', { 
      employee: null,
      message: 'No data found in session'
    });
  }
});

app.get('/employee/clear', (req, res) => {
  delete req.session.employee;
  
  req.session.message = 'Employee data cleared from session!';
  
  res.redirect('/');
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});