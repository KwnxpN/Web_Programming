const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./customers.db', (err) => {
  if (err) {
    console.error('Error connecting to database:', err.message);
  } else {
    console.log('Connected to the employee database.');
    
    db.run(`CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY,
      firstname TEXT NOT NULL,
      lastname TEXT NOT NULL,
      address TEXT,
      email TEXT,
      phone TEXT
    )`, (err) => {
      if (err) {
        console.error('Error creating table:', err.message);
      } else {
        console.log('Employees table ready');
        
        db.get('SELECT COUNT(*) as count FROM employees', (err, row) => {
          if (err) {
            console.error('Error checking employee count:', err.message);
            return;
          }
          
          if (row.count === 0) {
            db.run(`INSERT INTO employees (id, firstname, lastname, address, email, phone) 
                    VALUES (?, ?, ?, ?, ?, ?)`, 
                    [12009, 'Luis', 'Gonçalves', 'Av. Brigadeiro Faria Lima', 'luisg@embraer.com.br', '2170 +55 (12) 3923-5555'], 
                    function(err) {
              if (err) {
                console.error('Error inserting sample data:', err.message);
              } else {
                console.log('Sample employee data inserted');
              }
            });
          }
        });
      }
    });
  }
});

module.exports = db;